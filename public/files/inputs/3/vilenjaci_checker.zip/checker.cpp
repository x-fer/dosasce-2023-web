#include <bits/stdc++.h>
using namespace std;

//broj funkcija
const int N = 1000;
const int BR_VIL = 200;

//koeficijenti funkije
vector<double> funkcije[1000];

//sweep line događaji za racunanje broja poklona
vector<pair<double, bool> > events[1000];

//vraca sakupljen broj poklona na funkciji između poc i kraj
int pokloni(double poc, double kraj, int funkcija) {
    vector<double> poly = funkcije[funkcija];
    double rez = 0;
    for (int i = 0; i < 5; i++) {
        int pot = 5 - i;
        rez += (poly[i] / pot) * pow(kraj, pot);
        rez -= (poly[i] / pot) * pow(poc, pot);
    }
    return rez;
}

int main() {

    //citanje funkcija
    ifstream file("input.txt");
    double a, b, c, d, e;
    int br = 0;
    while (file >> a >> b >> c >> d >> e) {
        vector<double> vek{a, b, c, d, e};
        funkcije[br++] = vek;
    }
    
    int number_of_switches;
    
    //citanje rasporeda vilenjaka
    for (int i = 0; i < BR_VIL; i++) {
        cin >> number_of_switches;

        int x;
        double y;
        double uk = 0;
        for (int j = 0; j <= number_of_switches; j++) {
            cin >> x >> y;
            if (uk + y > 24 || x >= N) {
                cout << 0;
                return 0;
            }
            events[x].push_back(make_pair(uk, 0));
            events[x].push_back(make_pair(uk + y, 1));
            uk += y + 0.1;
        }
    }

    //racunanje rezultata
    int rezultat = 0;
    for (int i = 0; i < N; i++) {
        sort(events[i].begin(), events[i].end());

        int akt = 0;
        double poc = 0;
        for (int j = 0; j < events[i].size(); j++) {
            if (events[i][j].second == 0) {
                if (akt == 0) {
                    poc = events[i][j].first;
                }
                akt++;
            } else {
                akt--;
                if (akt == 0) {
                    rezultat += pokloni(poc, events[i][j].first, i);
                }
            }
        }
    }

    cout << rezultat;
    return 0;
}
